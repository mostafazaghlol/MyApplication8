package com.mostafazaghloul.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<String>  items=new ArrayList<>();
    ArrayList<String>  Prices=new ArrayList<>();
    ArrayList<String>  Quantity=new ArrayList<>();
    private List<dataIn> movieList = new ArrayList<>();
    private RecyclerView recyclerView;
    private dataAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        items.add("طعميه");
        items.add("فول");
        items.add("بطاطس");
        items.add("بطنجان");
        items.add("قلقاس");
        Prices.add("1");
        Prices.add("2");
        Prices.add("3");
        Prices.add("4");
        Prices.add("5");
        Quantity.add("27");
        Quantity.add("30");
        Quantity.add("35");
        Quantity.add("40");
        Quantity.add("45");

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        mAdapter = new dataAdapter(movieList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        prepareMovieData();
    }

    private void prepareMovieData() {
        for(int i=0;i<items.size();i++){
            dataIn mDataIn = new dataIn(items.get(i)
            ,Prices.get(i)
            ,Quantity.get(i));
            movieList.add(mDataIn);
        }
        mAdapter.notifyDataSetChanged();
    }
}
